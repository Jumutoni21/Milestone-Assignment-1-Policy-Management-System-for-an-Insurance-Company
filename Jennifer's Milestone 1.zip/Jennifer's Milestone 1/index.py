from policyholder import Policyholder
from product import Product
from payment import Payment

# Creating instances of Policyholders
policyholder1 = Policyholder(policyholder_id=1, name="Alice Johnson")
policyholder2 = Policyholder(policyholder_id=2, name="Dan Smith")

# Creating a product
product1 = Product(product_id=101, product_name="Health Insurance")

# Registering policyholders
policyholder1.register()
policyholder2.register()

# Suspending and reactivating a policyholder
policyholder1.suspend()
policyholder1.reactivate()

# Processing payments for policyholders
payment1 = Payment(payment_id=1001, policyholder=policyholder1, amount=200)
payment2 = Payment(payment_id=1002, policyholder=policyholder2, amount=300)

# Process the payments
payment1.process_payment()
payment2.process_payment()

# Send reminders
payment1.send_reminder()
payment2.send_reminder()

# Apply penalty
payment1.apply_penalty(50)

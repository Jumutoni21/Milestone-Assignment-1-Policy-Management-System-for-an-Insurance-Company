class Product:
    def __init__(self, product_id, product_name, is_active=True):
        self.product_id = product_id
        self.product_name = product_name
        self.is_active = is_active

    # Getters
    def get_product_id(self):
        return self.product_id

    def get_product_name(self):
        return self.product_name

    def get_product_status(self):
        return "Active" if self.is_active else "Suspended"

    # Setters
    def set_product_name(self, product_name):
        self.product_name = product_name

    def create_product(self):
        print(f"Product '{self.product_name}' created successfully.")

    def update_product(self, new_name):
        self.product_name = new_name
        print(f"Product updated to '{self.product_name}'.")

    def suspend_product(self):
        self.is_active = False
        print(f"Product '{self.product_name}' has been suspended.")

class Policyholder:
    def __init__(self, policyholder_id, name, is_active=True):
        self.policyholder_id = policyholder_id
        self.name = name
        self.is_active = is_active

    # Getters
    def get_policyholder_id(self):
        return self.policyholder_id

    def get_name(self):
        return self.name

    def get_status(self):
        return "Active" if self.is_active else "Suspended"

    # Setters
    def set_name(self, name):
        self.name = name

    def register(self):
        self.is_active = True
        print(f"{self.name} has been registered.")

    def suspend(self):
        self.is_active = False
        print(f"{self.name} has been suspended.")

    def reactivate(self):
        self.is_active = True
        print(f"{self.name} has been reactivated.")
